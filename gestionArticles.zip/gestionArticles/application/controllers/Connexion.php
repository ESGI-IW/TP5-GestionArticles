<?php

session_start();

/**
 * Classe Connexion.
 */
class Connexion extends CI_Controller {

    /**
     * Constructeur Connexion.
     */
    public function __construct() {
        parent::__construct();
        $this->load->model('utilisateurs/utilisateurs');
        $this->load->helper('url_helper');
        $this->load->helper('cookie');
    }

    /**
     * Controleur index
     * @param type $page
     */
    public function index($page = 'Connexion') {
        //Chargement de la helper et de la library
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = ucfirst($page); //Insere un titre
        //rend les champs obligatoire
        $this->form_validation->set_rules('loginUser', 'Login', 'required');
        $this->form_validation->set_rules('mdpUser', 'Mot de passe', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/nav');
            $this->load->view('connexion/formulaire', $data);
            $this->load->view('templates/footer');
        } else {
            if (empty($this->input->post('loginUser')) || empty($this->input->post('mdpUser'))) {//Cas où les champs sont vides
                echo "<script>alert('Veuillez remplir tous les champs!');</script>";
            } else if ($this->utilisateurs->estpresent() == true) {//Cas où les identifiants et mot de passe correspondent
                //Initialisation des variables de sessions
                $_SESSION['loginUser'] = $this->input->post('loginUser');
                $_SESSION['mdpUser'] = $this->input->post('mdpUser');
                $_SESSION['role'] = $this->utilisateurs->getrole();
                //Initialisation des variables cookies
                $this->input->set_cookie('loginUser', $_SESSION['loginUser'], 86400, TRUE);
                $this->input->set_cookie('mdpUser', $_SESSION['mdpUser'], 86400, TRUE);
                //redirection sur la page d'accueil
                redirect('accueil');
            } else {
                echo "<script>alert('Login ou Mot de passe incorrect!');</script>";
                //Chargement de la vue
                $this->load->view('templates/header', $data);
                $this->load->view('templates/nav');
                $this->load->view('connexion/formulaire', $data);
                $this->load->view('templates/footer');
            }
        }
    }

    /**
     * Controleur Deconnexion
     */
    public function deconnexion() {
        // Ferme la session (se déconnecter) et renvoie l'utilisateur vers la page de connexion
        unset($_SESSION['loginUser']);
        unset($_SESSION['mdpUser']);
        session_destroy();
        redirect('connexion', 'refresh');
    }

}
