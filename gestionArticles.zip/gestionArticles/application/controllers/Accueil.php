<?php

session_start();

/**
 * Classe accueil.
 * 
 */
class Accueil extends CI_Controller {

    /**
     * Constructeur Accueil.
     */
    public function __construct() {
        parent::__construct();

        $this->load->helper('url_helper');
    }

    public function index($page = 'accueil') {
        $this->load->helper('url_helper');

        if (!file_exists(APPPATH . '/views/accueil/' . $page . '.php')) {
            //On affiche une erreur.
            show_404();
        }
        //Chargement du titre.
        $data['title'] = ucfirst($page); 
        //Chargement des vues.
        $this->load->view('templates/header', $data);
        $this->load->view('templates/nav');

        $this->load->view('accueil/' . $page);
        $this->load->view('templates/footer', $data);
    }

}
