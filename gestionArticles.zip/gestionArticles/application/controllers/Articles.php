<?php

session_start();

/**
 * Classe Articles.
 *
 */
class Articles extends CI_Controller {

    /**
     * Constructeur Articles.
     */
    public function __construct() {
        parent::__construct();
        $this->load->model('articles/articles_modele');
        $this->load->model('auteurs/auteurs');
        $this->load->model('themes/themes');
        $this->load->helper('url_helper');
    }

    /**
     * Controleur vue.
     * @param type $page
     */
    public function index($page = 'articles') {
        $data['title'] = ucfirst($page); //Insere un titre
        $articles['articles'] = $this->articles_modele->get_articles();
        //Chargement de la vue.
        $this->load->view('templates/header', $data);
        $this->load->view('templates/nav');
        $this->load->view('articles/articles', $articles);
        $this->load->view('templates/footer');
    }

    /**
     * Controleur themes.
     * @param boolean $id
     */
    public function themes($id = FALSE) {
        $title['title'] = 'articles par themes';
        $articles['articles'] = $this->themes->get_themes();

        //Chargement de la vue.
        $this->load->view('templates/header', $title);
        $this->load->view('templates/nav');
        $this->load->view('articles/themes', $articles);

        if (!$this->themes->estpresent($id)) {
            //si l'id du theme l'existe pas on fait rien.
        } else {//autre cas on charge la vue   
            $articles['articles'] = $this->articles_modele->get_articlesTheme($id);
            $this->load->view("articles/articlesThemes", $articles);
        }
        //Chargement du pied de page.
        $this->load->view('templates/footer');
    }

    /**
     * Controleur auteurs.
     * @param boolean $id
     */
    public function auteurs($id = FALSE) {
        $title['title'] = 'articles Par auteurs';
        $articles['articles'] = $this->auteurs->get_auteurs();

        //Chargement de la vue.
        $this->load->view('templates/header', $title);
        $this->load->view('templates/nav');
        $this->load->view('articles/auteurs', $articles);

        if (!$this->auteurs->estpresent($id)) {
            //si l'id de l'auteur n'exite pas on fait rien.
        } else {//autre cas on charge la vue  
            $articles['articles'] = $this->articles_modele->get_articlesAuteur($id);
            $this->load->view("articles/articlesAuteurs", $articles);
        }
        //Chargement du pied de page.
        $this->load->view('templates/footer');
    }
    
    /**
     * Controleur ajouterArticle.
     */
    public function ajouterArticle() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] != 1) {
            redirect('accueil/index');
        }

        //Chargement de la helper et de la library
        $this->load->helper('form');
        $this->load->library('form_validation');
        //Chargement des données
        $data['title'] = "Formulaire d'ajout d'un article";
        $donnees['title'] = "Formulaire d'ajout d'un article";
        $donnees['utilisateurs'] = $this->auteurs->get_auteurs();
        //Rend les champs obligatoire
        $this->form_validation->set_rules('titre', 'Titre', 'required');
        $this->form_validation->set_rules('date', 'Date', 'required');
        $this->form_validation->set_rules('texte', 'Texte', 'required');
        $this->form_validation->set_rules('idUser', 'idUser', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/nav');
            $this->load->view('articles/ajout_article', $donnees);
            $this->load->view('templates/footer');
        } else {
            $this->articles_modele->ajouter_article();
            $title['title'] = 'articles Par auteurs';
            $this->load->view('templates/header', $title);
            $this->load->view('templates/nav');
            $this->load->view('articles/success');
            $this->load->view('templates/footer');
        }
    }

}
