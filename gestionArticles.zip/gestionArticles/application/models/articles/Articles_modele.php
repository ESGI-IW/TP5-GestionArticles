<?php

/**
 * Classe Articles_modele.
 */
class Articles_modele extends CI_Model {

    /**
     * Constructeur Articles_modele.
     * Permet de charger la connexion à la base de données.
     */
    public function __construct() {
        $this->load->database();
    }

    /**
     * Retourne un ou plusieurs articles.
     * @param type $titre
     * @return type
     */
    public function get_articles($titre = FALSE) {
        if ($titre == FALSE) {//On affiche tous les articles.
            //Requete permettant de recupérer tous les articles.
            $this->db->select('*');
            $this->db->from('Article');
            $this->db->join('Utilisateur', 'Utilisateur.idUser = Article.idUser');
            $requete = $this->db->get();
            //Retourne un array
            return $requete->result_array();
        }
        //Cas ou il y a un parametre
        $requete = $this->db->get_where('Article', array('titre' => $titre));
        return $requete->row_array();
    }

    /**
     * Retourne plusieurs articles d'un theme en fonction de son id.
     * @param int $id
     * @return int
     */
    public function get_articlesTheme($id) {
        $this->db->select('*');
        $this->db->from('Article');
        $this->db->join('Utilisateur', 'Utilisateur.idUser = Article.idUser');
        $this->db->join('possede', 'Article.idArticle = possede.idArticle');
        $this->db->join('Theme', 'Theme.idTheme = possede.idTheme');
        $this->db->where('possede.idTheme', $id);
        $requete = $this->db->get();
        //Retourne un array
        return $requete->result_array();
    }

    /**
     * Retourne plusieurs articles d'un auteur en fonction de son id.
     * @param type $id
     */
    public function get_articlesAuteur($id) {
        $this->db->select('*');
        $this->db->from('Article');
        $this->db->join('Utilisateur', 'Utilisateur.idUser = Article.idUser');
        $this->db->where('Article.idUser', $id);
        $requete = $this->db->get();
        //Retourne un array
        return $requete->result_array();
    }
    
    /**
     * Recupere les champs et ajoute un article.
     * @return type
     */
    public function ajouter_article(){
        $this->load->helper('url');
        
        $data = array('titre' => $this->input->post('titre'),
            'dateArt' => $this->input->post('date'),
            'texte' => $this->input->post('texte'),
            'idUser' => $this->input->post('idUser'),
        );
        //Insertion des données
        return $this->db->insert('Article',$data);
    }

}
