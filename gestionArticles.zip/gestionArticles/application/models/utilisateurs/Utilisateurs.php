<?php

/**
 * Classe Utilisateurs
 */
class Utilisateurs extends CI_Model {

    /**
     * Constructeur Utilisateurs
     */
    public function __construct() {
        $this->load->database();
    }

    /**
     * Retourne true si l'utilisateur est référencé.
     */
    public function estPresent() {
        $this->load->helper('url');

        $this->db->select('loginUser,mdpUser');
        $this->db->from('Utilisateur');
        $this->db->where(array('loginUser' => $this->input->post('loginUser'), 'mdpUser' => $this->input->post('mdpUser')));
        $requete = $this->db->get();
        $result = $requete->row_array();
        return $result['loginUser'] == $this->input->post('loginUser') && $result['mdpUser'] == $this->input->post('mdpUser');
    }
    
    /**
     * Retourne le role de l'utilisateur.
     * @return String
     */
    public function getRole() {
        $this->load->helper('url');
        $this->db->select('role');
        $this->db->from('Utilisateur');
        $this->db->where(array('loginUser' => $this->input->post('loginUser'), 'mdpUser' => $this->input->post('mdpUser')));
        $requete = $this->db->get();
        $result = $requete->row_array();
        return $result['role'];
    }

}
