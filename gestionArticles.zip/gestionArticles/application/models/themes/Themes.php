<?php

/**
 * Classe Themes.
 */
class Themes extends CI_Model {

    /**
     * Constructeur Themes.
     */
    public function __construct() {
        $this->load->database();
    }

    /**
     * Retourne tous les themes.
     * @return array
     */
    public function get_themes() {
        $this->db->select('*');
        $this->db->from('Theme');
        $requete = $this->db->get();

        return $requete->result_array();
    }
    
    /**
     * Retourne true si l'id du theme est present.
     * @param type $id
     * @return boolean
     */
    public function estPresent($id) {
        $this->db->select('idTheme');
        $this->db->from('possede');
        $this->db->where('possede.idTheme', $id);
        $requete = $this->db->get();
        $result = $requete->result_array();
        foreach ($result as $row):
            return $row['idTheme'] == $id ? true : false;
        endforeach;
    }

}
