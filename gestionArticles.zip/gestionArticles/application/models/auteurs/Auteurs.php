<?php

/**
 * Classe Auteurs
 */
class Auteurs extends CI_Model {

    /**
     * Constructeur Auteurs.
     * Permet de charger la connexion à la base de données.
     */
    public function __construct() {
        $this->load->database();
    }

    /**
     * Retourne tous les auteurs.
     * @return array
     */
    public function get_auteurs() {
        $this->db->select('*');
        $this->db->from('Utilisateur');
        $requete = $this->db->get();
        //retourne un array
        return $requete->result_array();
    }

    /**
     * Retourne true si l'id de l'auteur existe.
     * @param type $id
     * @return type
     */
    public function estPresent($id) {
        $this->db->select('idUser');
        $this->db->from('Article');
        $this->db->where('idUser', $id);
        $requete = $this->db->get();
        $result = $requete->result_array();
        //Parcours de l'array
        foreach ($result as $row):
            if ($row['idUser'] == $id)
                return true;
        endforeach;
        return false;
    }

}
