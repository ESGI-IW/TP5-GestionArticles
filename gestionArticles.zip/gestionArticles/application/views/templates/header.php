<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <!-- Titre de la page -->
        <title><?php echo $title; ?></title>
        <!-- Inclusion du fichier css -->
        <link rel="stylesheet" href="<?php echo base_url("assets/css/style.css"); ?>" />
    </head>
    <body>
        <header>

        </header>