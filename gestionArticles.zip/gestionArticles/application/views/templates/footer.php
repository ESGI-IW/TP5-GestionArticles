
<footer> <p>Site de gestion de base de données.<br>Lycée René Descartes<br>2016</p></footer>
</body>
</html>


