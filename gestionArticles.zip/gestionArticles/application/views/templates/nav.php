<!-- Partie navigation -->
<nav>
    <ul>
        <?php
        echo anchor("Accueil/index", "<li>accueil</li>");
        echo anchor("Articles/index", "<li>articles</li>");
        if (isset($_SESSION['loginUser']) && $_SESSION['role'] == 1) {
            echo anchor("Articles/ajouterarticle", "<li>ajout article</li>");
        }
        echo anchor("Articles/auteurs", "<li>auteurs</li>");
        echo anchor("Articles/themes", "<li>themes</li>");

        if (isset($_SESSION['loginUser'])) {
            echo anchor("Connexion/deconnexion", "<li>deconnexion</li>");
        } else {
            echo anchor("Connexion/index", "<li>connnexion</li>");
        }
        ?>
    </ul>
</nav>  
