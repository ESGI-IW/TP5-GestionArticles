<section>

    <h1> Auteurs</h1>
    <ul>
        <?php
        foreach ($articles as $article):
            echo anchor("Articles/auteurs/" . $article['idUser'] . "", " <li>" . $article['nomUser'] . " " . $article['prenomUser'] . "</li>");
        endforeach;
        ?>
    </ul>
    <br><br>
</section>