<section>
    <h1><?php echo $title; ?></h1>

    <?php echo validation_errors(); ?>

    <?php echo form_open('articles/ajouterArticle'); ?>
    
    <p><label for="titre">Titre</label>
        <input type="text" name="titre" /></p>

    <p><label for="date">Date</label>
        <input type="date" name="date"></p>

    <p><label for="texte">Texte</label>
        <textarea name="texte" style="resize:none;"></textarea></p>

    <?php
    echo '<select name="idUser">';
    echo '<option value="0" selected="selected">Sélectionner l\'utilisateur </option>';
    foreach ($utilisateurs as $utilisateur):
        echo "<option value=\"" . $utilisateur['idUser'] . " \">" . $utilisateur['idUser'] . " - " . $utilisateur['nomUser'] . " - " . $utilisateur['prenomUser'] . " - " . "</option>";
    endforeach;

    echo '</select>';
    ?>
    <br><br><center>
    
    <button >Créer un article</button>
    </center>
    <br>
</form>
</section>