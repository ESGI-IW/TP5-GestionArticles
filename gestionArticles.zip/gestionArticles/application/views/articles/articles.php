<h1 align='center'>Liste des articles</h1>
<table border="1">
    <tr>
        <th>Titre</th>
        <th>Date</th>
        <th>Texte</th>
        <th>Nom Auteur</th>
    </tr>
    <?php
    //Affichage des données.
    foreach ($articles as $article):
        echo "<tr><td>" . $article['titre'] . "</td>" .
        "<td>" . $article['dateArt'] . "</td>" .
        "<td>" . $article['texte'] . "</td>" .
        "<td>" . $article['nomUser'] . "</td>" .
        "</tr>";

    endforeach;
    ?>
</table>
<br>
<center>
    <a href="themes"><button>consulter les themes</button></a><br><br>
    <a href="auteurs"><button>consulter les auteurs</button></a>
</center>