<section>
    <h1>Themes</h1>
    <ul>
<?php

foreach ($articles as $article):
    echo anchor("Articles/themes/" . $article['idTheme'] . " ", " <li>" . $article['nomTheme']."</li>");
endforeach;
?>
    </ul>
    <br><br>

</section>