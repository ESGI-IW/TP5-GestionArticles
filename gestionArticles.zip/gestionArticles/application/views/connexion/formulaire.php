<section>
<h1 align="center"><?php echo $title; ?></h1>
<?php echo validation_errors(); ?>

<?php echo form_open('Connexion/index'); ?>
<?php
if ($this->input->cookie('loginUser', TRUE) !== null) {
    echo "<p><label for='login'>Login :</label>
<input type='text' id='login' name='loginUser' value='" . $this->input->cookie('loginUser') . "'></p>";
} else {
    echo "<p><label for='login'>Login :</label>
<input type='text' id='login' name='loginUser'></p>";
}

if ($this->input->cookie('loginUser', TRUE) !== null) {
    echo "<p><label for='mdp'>Mot de passe :</label>
<input type='password' id='mdp' name='mdpUser' value='" . $this->input->cookie('mdpUser') . "'></p>";
} else {
    echo "<p><label for='mdp'>Mot de passe :</label>
<input type='password' id='mdp' name='mdpUser'></p>";
}
?>


<center>
    <button>connexion</button>
</center>
<br>
</form>
</section>