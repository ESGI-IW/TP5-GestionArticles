<section>
 
    <p>Cette application a été réalisée avec le framework CodeIgniter utilisant le patron de conception MVC (Modèle,Vue,Controleur).
    </p>
    <p>La finalité de cette application est de gérer des articles d'informations internes à une entreprise.</p>
    <p>Seul l'administrateur à la possibilité de se connecter pour ajouter des articles à la base de données.</p>

</section>

